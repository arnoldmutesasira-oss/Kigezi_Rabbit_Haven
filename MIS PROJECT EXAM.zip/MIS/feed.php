<?php include 'db.php'; ?>
<!DOCTYPE html><html><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Feed - Kigezi Rabbit Haven</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css">
</head><body>
<div class="topbar d-flex justify-content-between"><div><h3 class="m-0"> <img src="logo2.jpeg" width=100px height=100;> FEED & STORE</h3><small>Receipts, Issues, Balance</small></div><div><div id="userLabel"></div><button class="btn btn-light btn-sm" onclick="logout()">Logout</button></div></div>
<div class="container-fluid p-3">
<ul class="nav nav-pills mb-3 flex-wrap">
  <li class="nav-item"><button class="nav-link" onclick="go('dashboard.php')">Dashboard</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('rabbits.php')">Rabbits</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('breeding.php')">Breeding</button></li>
  <li class="nav-item"><button class="nav-link active" onclick="go('feed.php')">Feed & Store</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('health.php')">Health</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('sales.php')">Sales</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('payments.php')">Payments</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('reports.php')">Reports</button></li>
</ul>
<div class="card p-3">
  <form method="POST" class="row g-2">
    <div class="col-md-3"><select name="feed" class="form-select"><?php $r=$conn->query("SELECT * FROM FEED_ITEM"); while($x=$r->fetch_assoc()) echo "<option value='{$x['FeedID']}'>{$x['ItemName']}</option>"; ?></select></div>
    <div class="col-md-2"><select name="type" class="form-select"><option>Issue</option><option>Receipt</option></select></div>
    <div class="col-md-2"><input name="qty" type="number" step="0.1" class="form-control" placeholder="Qty (kg)" required></div>
    <div class="col-md-2"><select name="shed" class="form-select"><option>Shed A</option><option>Shed B</option><option>Shed C</option><option>Nursery</option></select></div>
    <div class="col-md-3"><button class="btn btn-green w-100" name="save">Save Transaction</button></div>
  </form>
  <?php
  if(isset($_POST['save'])){
    $fid=$_POST['feed']; $qty=$_POST['qty']; $type=$_POST['type'];
    $conn->query("INSERT INTO FEED_TRANSACTION (FeedID,Type,Quantity,Shed,TxnDate) VALUES ($fid,'$type',$qty,'{$_POST['shed']}',CURDATE())");
    $sign = $type=='Receipt' ? '+' : '-';
    $conn->query("UPDATE FEED_ITEM SET Balance = Balance $sign $qty WHERE FeedID=$fid");
    echo "<div class='alert alert-success mt-2'>$type saved: $qty kg. Balance updated.</div>";
  }
  ?>
  <table class="table mt-3"><thead><tr><th>Item</th><th>Balance</th><th>Re-order Level</th><th>Status</th></tr></thead><tbody>
  <?php $r=$conn->query("SELECT * FROM FEED_ITEM"); while($x=$r->fetch_assoc()){
    $status = $x['Balance'] <= $x['ReorderLevel'] ? '<span class="badge bg-danger">LOW - REORDER</span>' : '<span class="badge bg-success">OK</span>';
    echo "<tr><td>{$x['ItemName']}</td><td>{$x['Balance']} kg</td><td>{$x['ReorderLevel']} kg</td><td>$status</td></tr>"; } ?>
  </tbody></table>
  <p>Feed Cost / Shed / Week: <b>UGX 285,000</b></p>
</div></div>
<script src="app.js"></script></body></html>