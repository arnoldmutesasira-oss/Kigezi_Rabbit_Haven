<?php include 'db.php'; ?>
<!DOCTYPE html><html><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Breeding - Kigezi Rabbit Haven</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css">
</head><body>
<div class="topbar d-flex justify-content-between"><div><h3 class="m-0"> <img src="logo2.jpeg" width=100px height=100;> BREEDING</h3><small>Mating, Kindling, Weaning</small></div><div><div id="userLabel"></div><button class="btn btn-light btn-sm" onclick="logout()">Logout</button></div></div>
<div class="container-fluid p-3">
<img src="images/rabbit.jpg" onerror="this.style.display='none'" class="farm-photo">
<ul class="nav nav-pills mb-3 flex-wrap">
  <li class="nav-item"><button class="nav-link" onclick="go('dashboard.php')">Dashboard</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('rabbits.php')">Rabbits</button></li>
  <li class="nav-item"><button class="nav-link active" onclick="go('breeding.php')">Breeding</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('feed.php')">Feed & Store</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('health.php')">Health</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('sales.php')">Sales</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('payments.php')">Payments</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('reports.php')">Reports</button></li>
</ul>
<div class="card p-3">
  <form method="POST" class="row g-2">
    <div class="col-md-3"><label>Doe ID</label><input name="doe" class="form-control" value="KRH-D042" required></div>
    <div class="col-md-3"><label>Buck ID</label><input name="buck" class="form-control" value="KRH-B007" required></div>
    <div class="col-md-3"><label>Mating Date</label><input type="date" name="mdate" class="form-control" required></div>
    <div class="col-md-3"><label>&nbsp;</label><button class="btn btn-green w-100" name="mate">Check & Save Mating</button></div>
  </form>
  <?php
  if(isset($_POST['mate'])){
    $doe=$_POST['doe']; $buck=$_POST['buck'];
    $d=$conn->query("SELECT DamID,SireID FROM RABBIT WHERE RabbitID='$doe'")->fetch_assoc();
    $b=$conn->query("SELECT DamID,SireID FROM RABBIT WHERE RabbitID='$buck'")->fetch_assoc();
    if($doe==$buck) echo '<div class="alert alert-danger mt-2">❌ BLOCKED: Same rabbit!</div>';
    elseif($d && $b && ($d['DamID']==$b['DamID'] || $d['SireID']==$b['SireID'] || $d['DamID']==$b['SireID'])) echo '<div class="alert alert-danger mt-2">❌ BLOCKED: INBREEDING! Same parent.</div>';
    else {
      $conn->query("INSERT INTO BREEDING_EVENT (DoeID,BuckID,MatingDate) VALUES ('$doe','$buck','{$_POST['mdate']}')");
      echo '<div class="alert alert-success mt-2">SAFE: '.$doe.' + '.$buck.' - Mating saved. Kindling expected in 31 days.</div>';
    }
  }
  ?>
  <hr>
  <form method="POST" class="row g-2">
    <div class="col-md-3"><input name="kdoe" class="form-control" placeholder="Doe ID for Kindling" required></div>
    <div class="col-md-2"><input name="born" type="number" class="form-control" placeholder="Kits Born" required></div>
    <div class="col-md-2"><input name="weaned" type="number" class="form-control" placeholder="Kits Weaned" required></div>
    <div class="col-md-2"><input name="kdate" type="date" class="form-control" required></div>
    <div class="col-md-3"><button class="btn btn-green w-100" name="kindle">Save Kindling</button></div>
  </form>
  <?php
  if(isset($_POST['kindle'])){
    $born=$_POST['born']; $weaned=$_POST['weaned']; $mort=$born?round(($born-$weaned)/$born*100,1):0;
    $conn->query("UPDATE BREEDING_EVENT SET KindlingDate='{$_POST['kdate']}', KitsBorn=$born, KitsWeaned=$weaned, Mortality=$mort WHERE DoeID='{$_POST['kdoe']}' ORDER BY EventID DESC LIMIT 1");
    echo "<div class='alert alert-success mt-2'>Kindling saved: Born $born, Weaned $weaned, Mortality $mort%</div>";
  }
  ?>
  <h5 class="mt-3">Recent Breeding Events</h5>
  <table class="table"><thead><tr><th>Doe</th><th>Buck</th><th>Mating</th><th>Born</th><th>Weaned</th><th>Mortality</th></tr></thead><tbody>
  <?php $res=$conn->query("SELECT * FROM BREEDING_EVENT ORDER BY EventID DESC LIMIT 10"); while($r=$res->fetch_assoc()) echo "<tr><td>{$r['DoeID']}</td><td>{$r['BuckID']}</td><td>{$r['MatingDate']}</td><td>{$r['KitsBorn']}</td><td>{$r['KitsWeaned']}</td><td>{$r['Mortality']}%</td></tr>"; ?>
  </tbody></table>
</div></div>
<script src="app.js"></script></body></html>