
<?php include 'db.php'; ?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Rabbits - Kigezi Rabbit Haven</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css">

</head>

<body>

<div class="topbar d-flex justify-content-between">

    <div>
        <h3 class="m-0">HERD REGISTER</h3>
        <small>Every Rabbit Has Unique ID + Dam / Sire</small>
    </div>

    <div>
        <div id="userLabel"></div>
        <button class="btn btn-light btn-sm" onclick="logout()">Logout</button>
    </div>

</div>

<div class="container-fluid p-3">

<ul class="nav nav-pills mb-3 flex-wrap">

    <li class="nav-item">
        <button class="nav-link" onclick="go('dashboard.php')">Dashboard</button>
    </li>

    <li class="nav-item">
        <button class="nav-link active" onclick="go('rabbits.php')">Rabbits</button>
    </li>

    <li class="nav-item">
        <button class="nav-link" onclick="go('breeding.php')">Breeding</button>
    </li>

    <li class="nav-item">
        <button class="nav-link" onclick="go('feed.php')">Feed & Store</button>
    </li>

    <li class="nav-item">
        <button class="nav-link" onclick="go('health.php')">Health</button>
    </li>

    <li class="nav-item">
        <button class="nav-link" onclick="go('sales.php')">Sales</button>
    </li>

    <li class="nav-item">
        <button class="nav-link" onclick="go('payments.php')">Payments</button>
    </li>

    <li class="nav-item">
        <button class="nav-link" onclick="go('reports.php')">Reports</button>
    </li>

</ul>

<div class="card p-3">

    <form method="POST" class="row g-2 mb-3">

        <div class="col-md-3">
            <input name="rid"
                   class="form-control"
                   placeholder="Rabbit ID e.g. KRH-D050"
                   required>
        </div>

        <div class="col-md-2">

            <select name="sex" class="form-select">
                <option>Doe</option>
                <option>Buck</option>
                <option>Kit</option>
                <option>Grower</option>
            </select>

        </div>

        <div class="col-md-2">
            <input name="breed"
                   class="form-control"
                   placeholder="Breed">
        </div>

        <div class="col-md-2">
            <input name="dam"
                   class="form-control"
                   placeholder="Dam ID">
        </div>

        <div class="col-md-2">
            <input name="sire"
                   class="form-control"
                   placeholder="Sire ID">
        </div>

        <div class="col-md-1">
            <button class="btn btn-green w-100" name="add">
                Add
            </button>
        </div>

    </form>


<?php

if (isset($_POST['add'])) {

    $rid = trim($_POST['rid']);
    $sex = $_POST['sex'];
    $breed = trim($_POST['breed']);

    $dam = trim($_POST['dam']) === '' ? null : trim($_POST['dam']);
    $sire = trim($_POST['sire']) === '' ? null : trim($_POST['sire']);

    // Check whether Dam exists
    if ($dam) {

        $stmt = $conn->prepare(
            "SELECT RabbitID FROM RABBIT WHERE RabbitID = ?"
        );

        $stmt->bind_param("s", $dam);
        $stmt->execute();

        $damExists = $stmt->get_result()->num_rows;
        $stmt->close();

    } else {

        $damExists = true;

    }

    // Check whether Sire exists
    if ($sire) {

        $stmt = $conn->prepare(
            "SELECT RabbitID FROM RABBIT WHERE RabbitID = ?"
        );

        $stmt->bind_param("s", $sire);
        $stmt->execute();

        $sireExists = $stmt->get_result()->num_rows;
        $stmt->close();

    } else {

        $sireExists = true;

    }

    if (!$damExists) {

        echo '<div class="alert alert-danger">
            Dam ID ' . htmlspecialchars($dam) . ' does not exist yet!
            Add the mother first, or leave Dam ID blank.
        </div>';

    } elseif (!$sireExists) {

        echo '<div class="alert alert-danger">
            Sire ID ' . htmlspecialchars($sire) . ' does not exist yet!
            Add the father first, or leave Sire ID blank.
        </div>';

    } else {

        try {

            $stmt = $conn->prepare(
                "INSERT INTO RABBIT
                (RabbitID, Sex, Breed, DamID, SireID, Status, DOB)
                VALUES (?, ?, ?, ?, ?, 'Active', CURDATE())"
            );

            $stmt->bind_param(
                "sssss",
                $rid,
                $sex,
                $breed,
                $dam,
                $sire
            );

            $stmt->execute();
            $stmt->close();

            echo '<div class="alert alert-success">
                Rabbit ' . htmlspecialchars($rid) . ' saved successfully!
            </div>';

        } catch (Exception $e) {

            echo '<div class="alert alert-danger">
                Could not save rabbit. Please check the Rabbit ID and database details.
            </div>';

        }

    }

}

?>


<!-- SEARCH RABBITS -->

<input
    class="form-control mb-2"
    placeholder="Search KRH-..."
    onkeyup="searchTable(this,'rabbitTable')"
>


<!-- HERD REGISTER TABLE -->

<div class="table-responsive">

<table class="table table-striped" id="rabbitTable">

    <thead class="table-dark">

        <tr>
            <th>Rabbit ID</th>
            <th>Sex / Breed</th>
            <th>DOB</th>
            <th>Dam</th>
            <th>Sire</th>
            <th>Status</th>
        </tr>

    </thead>

    <tbody>

    <?php

    $res = $conn->query("SELECT * FROM RABBIT");

    while ($r = $res->fetch_assoc()) {

        echo "<tr>";

        echo "<td>" . htmlspecialchars($r['RabbitID']) . "</td>";

        echo "<td>" . htmlspecialchars($r['Sex']) . " - " .
             htmlspecialchars($r['Breed']) . "</td>";

        echo "<td>" . htmlspecialchars($r['DOB']) . "</td>";

        echo "<td>" . htmlspecialchars($r['DamID'] ?? '') . "</td>";

        echo "<td>" . htmlspecialchars($r['SireID'] ?? '') . "</td>";

        echo "<td>" . htmlspecialchars($r['Status']) . "</td>";

        echo "</tr>";

    }

    ?>

    </tbody>

</table>

</div>

<small class="text-success">
    Inbreeding Check: System blocks mating if Doe & Buck share same Dam/Sire within 2 generations.
</small>

</div>

</div>

<script src="app.js"></script>

</body>
</html>
