<!DOCTYPE html><html><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login - Kigezi Rabbit Haven</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="topbar text-center">
  <img src="images/rabbit.jpg" onerror="this.style.display='none'" style="width:100px;height:100px;object-fit:cover;border-radius:50%;">
  <h3> KIGEZI RABBIT HAVEN </h3><small>Bubare Trading Centre, Kabale District</small>
</div>
<div class="container mt-4" style="max-width:450px">
  <div class="card p-4">
    <h4 class="text-center">Login</h4>
    <label>Username</label><input id="username" class="form-control" placeholder="e.g. owner">
    <label class="mt-2">Password</label><input type="password" class="form-control" placeholder="1234">
    <label class="mt-2">Role</label>
    <select id="role" class="form-select">
      <option>Owner / Manager</option><option>Production Supervisor</option>
      <option>Sales Officer</option><option>Storekeeper</option><option>Farm Attendant</option>
    </select>
    <button class="btn btn-green w-100 mt-3 big-btn" onclick="login()">Login</button>
    <small class="text-muted d-block mt-2 text-center">Demo: any username / password works. Role controls access.</small>
  </div>
</div>
<script src="app.js"></script>
<script>
function login(){
  let role=document.getElementById('role').value;
  let user=document.getElementById('username').value || 'Owner';
  localStorage.setItem('krh_user', role+' - '+user);
  audit('Logged in as '+role);
  window.location.href='dashboard.php';
}
</script></body></html>