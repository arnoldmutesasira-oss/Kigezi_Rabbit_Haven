<!DOCTYPE html><html><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Dashboard - Kigezi Rabbit Haven</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css">
</head><body>
<div class="topbar d-flex justify-content-between"><div><h3 class="m-0"> <img src="logo2.jpeg" width=100px height=100;> KIGEZI RABBIT HAVEN</h3><small>Bubare, Kabale | Dashboard</small></div><div><div id="userLabel"></div><button class="btn btn-light btn-sm" onclick="logout()">Logout</button></div></div>
<div class="container-fluid p-3">
<img src="images/rabbit.jpg" onerror="this.style.display='none'" class="farm-photo" alt="Farm">
<ul class="nav nav-pills mb-3 flex-wrap">
  <li class="nav-item"><button class="nav-link active" onclick="go('dashboard.php')">Dashboard</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('rabbits.php')">Rabbits</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('breeding.php')">Breeding</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('feed.php')">Feed & Store</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('health.php')">Health</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('sales.php')">Sales</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('payments.php')">Payments</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('reports.php')">Reports</button></li>
</ul>

<div class="row g-3 mt-1">
  <div class="col-md-8"><div class="card p-3"><h5> TODAY'S TASK LIST [FR8]</h5>
    <ul class="list-group"><li class="list-group-item"> Feed Shed A - 12.5kg Pellets</li><li class="list-group-item">● Mate Doe KRH-D042 with Buck KRH-B007 <span class="badge bg-success">SAFE</span></li><li class="list-group-item">● Kindling Check - Doe KRH-D018 (Day 31)</li><li class="list-group-item">● Wean Litter L-104 - 8 kits</li><li class="list-group-item">⚠ Vaccinate Shed C - 45 growers</li></ul>
  </div></div>
  
</div>
</div>
<script src="app.js"></script></body></html>