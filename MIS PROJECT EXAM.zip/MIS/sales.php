
<?php include 'db.php'; ?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Sales - Kigezi Rabbit Haven</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css">

</head>

<body>

<div class="topbar d-flex justify-content-between">

    <div>
        <h3 class="m-0">
            <img src="logo2.jpeg" width="100" height="100" alt="Logo">
            SALES
        </h3>
        <small>Order → Invoice (UC-05)</small>
    </div>

    <div>
        <div id="userLabel"></div>
        <button class="btn btn-light btn-sm" onclick="logout()">Logout</button>
    </div>

</div>

<div class="container-fluid p-3">

<ul class="nav nav-pills mb-3 flex-wrap">

    <li class="nav-item">
        <button class="nav-link" onclick="go('dashboard.php')">Dashboard</button>
    </li>

    <li class="nav-item">
        <button class="nav-link" onclick="go('rabbits.php')">Rabbits</button>
    </li>

    <li class="nav-item">
        <button class="nav-link" onclick="go('breeding.php')">Breeding</button>
    </li>

    <li class="nav-item">
        <button class="nav-link" onclick="go('feed.php')">Feed & Store</button>
    </li>

    <li class="nav-item">
        <button class="nav-link" onclick="go('health.php')">Health</button>
    </li>

    <li class="nav-item">
        <button class="nav-link active" onclick="go('sales.php')">Sales</button>
    </li>

    <li class="nav-item">
        <button class="nav-link" onclick="go('payments.php')">Payments</button>
    </li>

    <li class="nav-item">
        <button class="nav-link" onclick="go('reports.php')">Reports</button>
    </li>

</ul>

<div class="card p-3">

    <form method="POST" class="row g-2">

        <div class="col-md-3">
            <input name="cust"
                   class="form-control"
                   placeholder="Customer e.g. Kisoro Hotel"
                   required>
        </div>

        <div class="col-md-3">

            <select name="prod" class="form-select" id="prod" onchange="calcTotal()">

                <option value="18000">Dressed Meat - 18,000 / kg</option>
                <option value="30000">Live Rabbit - 30,000</option>
                <option value="60000">Breeding Doe - 60,000</option>
                <option value="50000">Breeding Buck - 50,000</option>
                <option value="3000">Manure Sack - 3,000</option>
                <option value="50000">Training - 50,000</option>

            </select>

        </div>

        <div class="col-md-2">
            <input name="qty"
                   id="qty"
                   type="number"
                   min="1"
                   value="10"
                   class="form-control"
                   onkeyup="calcTotal()"
                   onchange="calcTotal()"
                   required>
        </div>

        <div class="col-md-2">
            <input id="total"
                   class="form-control fw-bold"
                   readonly
                   value="180,000">
        </div>

        <div class="col-md-2">
            <button class="btn btn-green w-100" name="order">
                Create Invoice
            </button>
        </div>

    </form>

    <?php

    if (isset($_POST['order'])) {

        $customer = trim($_POST['cust']);
        $product = (int)$_POST['prod'];
        $qty = (int)$_POST['qty'];

        $total = $product * $qty;

        if ($customer !== '' && $qty > 0 && $product > 0) {

            // Save customer
            $stmt = $conn->prepare(
                "INSERT INTO CUSTOMER (CustomerName) VALUES (?)"
            );

            $stmt->bind_param("s", $customer);
            $stmt->execute();

            $cid = $conn->insert_id;
            $stmt->close();

            // Save order
            $stmt = $conn->prepare(
                "INSERT INTO `ORDER`
                (CustomerID, OrderDate, Product, Quantity, Total, Status)
                VALUES (?, CURDATE(), ?, ?, ?, 'Pending')"
            );

            $stmt->bind_param("iidi", $cid, $product, $qty, $total);

            if ($stmt->execute()) {

                $oid = $conn->insert_id;

                echo "
                <div class='card p-3 mt-3'>

                    <h5>INVOICE INV-$oid - Kigezi Rabbit Haven</h5>

                    <p>
                        Customer: " . htmlspecialchars($customer) . "<br>
                        Qty: " . htmlspecialchars($qty) . "<br>
                        <b>Total: UGX " . number_format($total) . "</b>
                    </p>

                    <button class='btn btn-primary' onclick='window.print()'>
                        Print / PDF
                    </button>

                </div>";

            } else {

                echo "<div class='alert alert-danger mt-3'>
                    Unable to create invoice.
                </div>";

            }

            $stmt->close();

        } else {

            echo "<div class='alert alert-danger mt-3'>
                Please enter valid customer and order details.
            </div>";

        }
    }

    ?>

</div>

</div>

<script src="app.js"></script>

<script>

function calcTotal() {

    let product = +document.getElementById('prod').value;
    let qty = +document.getElementById('qty').value || 0;

    document.getElementById('total').value =
        (product * qty).toLocaleString();

}

</script>

</body>
</html>
