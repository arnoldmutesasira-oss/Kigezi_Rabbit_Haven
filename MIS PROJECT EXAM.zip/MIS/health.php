
<?php
include 'db.php';

$message = "";
$messageType = "success";

/* Safe output */
function e($value) {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

/* Automatically create missing medication columns */
try {
    $check = $conn->query("SHOW COLUMNS FROM HEALTH_CASE LIKE 'MedicationName'");

    if ($check && $check->num_rows == 0) {
        $conn->query("
            ALTER TABLE HEALTH_CASE
            ADD COLUMN MedicationName VARCHAR(150) NULL
        ");
    }

    $check = $conn->query("SHOW COLUMNS FROM HEALTH_CASE LIKE 'Dosage'");

    if ($check && $check->num_rows == 0) {
        $conn->query("
            ALTER TABLE HEALTH_CASE
            ADD COLUMN Dosage VARCHAR(100) NULL
        ");
    }

} catch (mysqli_sql_exception $ex) {
    $message = "Database setup error: " . $ex->getMessage();
    $messageType = "danger";
}

/* Save health record */
if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['save_health'])
    && $message === ''
) {
    $rabbitID = trim($_POST['RabbitID'] ?? '');
    $diagnosis = trim($_POST['Diagnosis'] ?? '');
    $medication = trim($_POST['MedicationName'] ?? '');
    $dosage = trim($_POST['Dosage'] ?? '');
    $treatment = trim($_POST['Treatment'] ?? '');
    $cost = (float)($_POST['DrugCost'] ?? 0);
    $outcome = trim($_POST['Outcome'] ?? 'Under Treatment');

    if ($diagnosis === 'Other') {
        $diagnosis = trim($_POST['OtherDiagnosis'] ?? '');
    }

    if ($medication === 'Other') {
        $medication = trim($_POST['OtherMedication'] ?? '');
    }

    $allowedOutcomes = [
        'Under Treatment',
        'Recovering',
        'Recovered',
        'Critical',
        'Referred',
        'Deceased'
    ];

    if ($rabbitID === '' || $diagnosis === '') {
        $message = "Please select a rabbit and enter a diagnosis.";
        $messageType = "danger";

    } elseif ($cost < 0) {
        $message = "Medication cost cannot be negative.";
        $messageType = "danger";

    } elseif (!in_array($outcome, $allowedOutcomes, true)) {
        $message = "Please select a valid health status.";
        $messageType = "danger";

    } else {
        try {
            /* Check that rabbit exists */
            $rabbitCheck = $conn->prepare(
                "SELECT RabbitID FROM RABBIT WHERE RabbitID = ?"
            );

            $rabbitCheck->bind_param("s", $rabbitID);
            $rabbitCheck->execute();

            $rabbitResult = $rabbitCheck->get_result();

            if ($rabbitResult->num_rows === 0) {
                $message = "The selected rabbit does not exist.";
                $messageType = "danger";

            } else {
                /* Insert health record */
                $stmt = $conn->prepare("
                    INSERT INTO HEALTH_CASE
                    (
                        RabbitID,
                        Diagnosis,
                        MedicationName,
                        Dosage,
                        Treatment,
                        DrugCost,
                        Outcome,
                        CaseDate
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, CURDATE())
                ");

                $stmt->bind_param(
                    "sssssds",
                    $rabbitID,
                    $diagnosis,
                    $medication,
                    $dosage,
                    $treatment,
                    $cost,
                    $outcome
                );

                if ($stmt->execute()) {
                    header("Location: health.php?saved=1");
                    exit;
                } else {
                    $message = "Unable to save health record.";
                    $messageType = "danger";
                }

                $stmt->close();
            }

            $rabbitCheck->close();

        } catch (mysqli_sql_exception $ex) {
            $message = "Saving failed: " . $ex->getMessage();
            $messageType = "danger";
        }
    }
}

/* Success message after saving */
if (isset($_GET['saved']) && $_GET['saved'] == '1') {
    $message = "Health record saved successfully!";
    $messageType = "success";
}

/* Load rabbits */
$rabbits = false;

try {
    $rabbits = $conn->query("
        SELECT RabbitID, Sex, Breed, DOB
        FROM RABBIT
        ORDER BY RabbitID ASC
    ");
} catch (mysqli_sql_exception $ex) {
    $message = "Unable to load rabbits: " . $ex->getMessage();
    $messageType = "danger";
}

/* Load health records */
$records = false;

try {
    $records = $conn->query("
        SELECT
            CaseID,
            RabbitID,
            Diagnosis,
            MedicationName,
            Dosage,
            Treatment,
            DrugCost,
            Outcome,
            CaseDate
        FROM HEALTH_CASE
        ORDER BY CaseID DESC
    ");
} catch (mysqli_sql_exception $ex) {
    $message = "Unable to load health records: " . $ex->getMessage();
    $messageType = "danger";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Health - Kigezi Rabbit Haven</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">

    <style>
        .health-container {
            padding: 20px;
        }

        .health-card {
            background: #fff;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
        }

        .health-card h4 {
            margin-bottom: 20px;
        }

        .form-label {
            font-weight: 600;
        }

        .rabbit-info {
            display: none;
            background: #f1f8f3;
            padding: 12px;
            border-radius: 8px;
            margin-top: 10px;
        }

        .table-responsive {
            overflow-x: auto;
        }

        .table th,
        .table td {
            vertical-align: middle;
            white-space: nowrap;
        }
    </style>
</head>

<body>

<!-- ORIGINAL GREEN TOPBAR -->
<div class="topbar d-flex justify-content-between align-items-center">

    <div>
        <h3 class="m-0 d-flex align-items-center gap-2">
            <img src="logo2.jpeg"
                 width="80"
                 height="80"
                 alt="Kigezi Rabbit Haven">
            HEALTH
        </h3>

        <small>Case per Rabbit</small>
    </div>

    <div class="text-end">
        <div id="userLabel"></div>

        <button class="btn btn-light btn-sm mt-2" onclick="logout()">
            Logout
        </button>
    </div>

</div>

<!-- NAVIGATION -->
<div class="container-fluid mt-3">

    <div class="d-flex flex-wrap gap-2 mb-3">

        <button class="btn btn-outline-success" onclick="go('index.php')">
            Dashboard
        </button>

        <button class="btn btn-outline-success" onclick="go('rabbits.php')">
            Rabbits
        </button>

        <button class="btn btn-outline-success" onclick="go('breeding.php')">
            Breeding
        </button>

        <button class="btn btn-outline-success" onclick="go('feed.php')">
            Feed & Store
        </button>

        <button class="btn btn-success" onclick="go('health.php')">
            Health
        </button>

        <button class="btn btn-outline-success" onclick="go('sales.php')">
            Sales
        </button>

        <button class="btn btn-outline-success" onclick="go('payments.php')">
            Payments
        </button>

        <button class="btn btn-outline-success" onclick="go('reports.php')">
            Reports
        </button>

    </div>

    <div class="health-container">

        <!-- ALERT MESSAGE -->
        <?php if ($message !== ''): ?>

            <div class="alert alert-<?php echo e($messageType); ?>">
                <?php echo e($message); ?>
            </div>

        <?php endif; ?>

        <!-- HEALTH RECORD FORM -->
        <div class="health-card">

            <h4>Record Rabbit Health Case</h4>

            <form method="POST" action="health.php">

                <div class="row g-3">

                    <!-- RABBIT SELECTION -->
                    <div class="col-md-6">

                        <label class="form-label">Select Rabbit</label>

                        <select name="RabbitID"
                                id="rabbitSelect"
                                class="form-select"
                                required>

                            <option value="">-- Select Registered Rabbit --</option>

                            <?php if ($rabbits): ?>

                                <?php while ($rabbit = $rabbits->fetch_assoc()): ?>

                                    <option
                                        value="<?php echo e($rabbit['RabbitID']); ?>"
                                        data-sex="<?php echo e($rabbit['Sex']); ?>"
                                        data-breed="<?php echo e($rabbit['Breed']); ?>"
                                        data-dob="<?php echo e($rabbit['DOB']); ?>">

                                        <?php echo e($rabbit['RabbitID']); ?>
                                        - <?php echo e($rabbit['Breed']); ?>

                                    </option>

                                <?php endwhile; ?>

                            <?php endif; ?>

                        </select>

                        <div class="rabbit-info" id="rabbitInfo">

                            <strong>Rabbit Information</strong>

                            <div>
                                Sex: <span id="rabbitSex"></span>
                            </div>

                            <div>
                                Breed: <span id="rabbitBreed"></span>
                            </div>

                            <div>
                                Date of Birth: <span id="rabbitDOB"></span>
                            </div>

                        </div>

                    </div>

                    <!-- DIAGNOSIS -->
                    <div class="col-md-6">

                        <label class="form-label">Diagnosis / Disease</label>

                        <select name="Diagnosis"
                                id="diagnosis"
                                class="form-select"
                                required>

                            <option value="">-- Select Disease --</option>

                            <option>Snuffles (Respiratory Infection)</option>
                            <option>Coccidiosis</option>
                            <option>Mange</option>
                            <option>Ear Mites</option>
                            <option>Ringworm</option>
                            <option>Bloat</option>
                            <option>Diarrhoea</option>
                            <option>Pasteurellosis</option>
                            <option>Dental Disease</option>
                            <option>Sore Hocks</option>
                            <option>Rabbit Haemorrhagic Disease (RHD)</option>
                            <option>Myxomatosis</option>
                            <option>Wounds / Injuries</option>
                            <option>Eye Infection</option>
                            <option>Loss of Appetite</option>
                            <option value="Other">Other</option>

                        </select>

                        <input type="text"
                               name="OtherDiagnosis"
                               id="otherDiagnosis"
                               class="form-control mt-2"
                               placeholder="Enter other diagnosis"
                               style="display:none;">

                    </div>

                    <!-- MEDICATION -->
                    <div class="col-md-6">

                        <label class="form-label">Select Medication</label>

                        <select name="MedicationName"
                                id="medication"
                                class="form-select">

                            <option value="">-- Select Medication --</option>

                            <option>Enrofloxacin</option>
                            <option>Trimethoprim-Sulfamethoxazole</option>
                            <option>Fenbendazole</option>
                            <option>Ivermectin</option>
                            <option>Selamectin</option>
                            <option>Toltrazuril</option>
                            <option>Meloxicam</option>
                            <option value="Other">Other</option>

                        </select>

                        <input type="text"
                               name="OtherMedication"
                               id="otherMedication"
                               class="form-control mt-2"
                               placeholder="Enter medication name"
                               style="display:none;">

                    </div>

                    <!-- DOSAGE -->
                    <div class="col-md-6">

                        <label class="form-label">Dosage</label>

                        <input type="text"
                               name="Dosage"
                               class="form-control"
                               placeholder="Enter veterinarian-prescribed dosage">

                    </div>

                    <!-- TREATMENT -->
                    <div class="col-md-6">

                        <label class="form-label">Treatment / Instructions</label>

                        <textarea name="Treatment"
                                  class="form-control"
                                  rows="3"
                                  placeholder="Enter treatment details"></textarea>

                    </div>

                    <!-- COST -->
                    <div class="col-md-6">

                        <label class="form-label">Medication Cost (UGX)</label>

                        <input type="number"
                               name="DrugCost"
                               class="form-control"
                               min="0"
                               step="1"
                               value="0">

                    </div>

                    <!-- STATUS -->
                    <div class="col-md-6">

                        <label class="form-label">Health Status</label>

                        <select name="Outcome" class="form-select">

                            <option>Under Treatment</option>
                            <option>Recovering</option>
                            <option>Recovered</option>
                            <option>Critical</option>
                            <option>Referred</option>
                            <option>Deceased</option>

                        </select>

                    </div>

                    <!-- SAVE BUTTON -->
                    <div class="col-12">

                        <button type="submit"
                                name="save_health"
                                class="btn btn-success px-4">

                            Save Health Record

                        </button>

                    </div>

                </div>

            </form>

        </div>

        <!-- HEALTH RECORDS TABLE -->
        <div class="health-card">

            <h4>Health Records</h4>

            <input type="text"
                   id="searchRecords"
                   class="form-control mb-3"
                   placeholder="Search rabbit, disease, medication or status...">

            <div class="table-responsive">

                <table class="table table-bordered table-striped"
                       id="healthTable">

                    <thead class="table-success">

                        <tr>
                            <th>Case</th>
                            <th>Rabbit ID</th>
                            <th>Diagnosis</th>
                            <th>Medication</th>
                            <th>Dosage</th>
                            <th>Treatment</th>
                            <th>Cost (UGX)</th>
                            <th>Outcome</th>
                            <th>Case Date</th>
                        </tr>

                    </thead>

                    <tbody>

                        <?php if ($records && $records->num_rows > 0): ?>

                            <?php while ($record = $records->fetch_assoc()): ?>

                                <tr>

                                    <td><?php echo e($record['CaseID']); ?></td>

                                    <td><?php echo e($record['RabbitID']); ?></td>

                                    <td><?php echo e($record['Diagnosis']); ?></td>

                                    <td><?php echo e($record['MedicationName']); ?></td>

                                    <td><?php echo e($record['Dosage']); ?></td>

                                    <td><?php echo e($record['Treatment']); ?></td>

                                    <td>
                                        <?php echo number_format((float)$record['DrugCost']); ?>
                                    </td>

                                    <td><?php echo e($record['Outcome']); ?></td>

                                    <td><?php echo e($record['CaseDate']); ?></td>

                                </tr>

                            <?php endwhile; ?>

                        <?php else: ?>

                            <tr>
                                <td colspan="9" class="text-center">
                                    No health records found.
                                </td>
                            </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

<script>

/* Navigation */
function go(page) {
    window.location.href = page;
}

/* Rabbit information */
document.getElementById('rabbitSelect').addEventListener('change', function () {

    const selected = this.options[this.selectedIndex];
    const info = document.getElementById('rabbitInfo');

    if (this.value !== '') {

        document.getElementById('rabbitSex').textContent =
            selected.dataset.sex || '';

        document.getElementById('rabbitBreed').textContent =
            selected.dataset.breed || '';

        document.getElementById('rabbitDOB').textContent =
            selected.dataset.dob || '';

        info.style.display = 'block';

    } else {

        info.style.display = 'none';

    }

});

/* Other diagnosis */
document.getElementById('diagnosis').addEventListener('change', function () {

    const other = document.getElementById('otherDiagnosis');

    other.style.display = this.value === 'Other' ? 'block' : 'none';

    other.required = this.value === 'Other';

});

/* Other medication */
document.getElementById('medication').addEventListener('change', function () {

    const other = document.getElementById('otherMedication');

    other.style.display = this.value === 'Other' ? 'block' : 'none';

    other.required = this.value === 'Other';

});

/* Search records */
document.getElementById('searchRecords').addEventListener('input', function () {

    const search = this.value.toLowerCase();

    const rows = document.querySelectorAll('#healthTable tbody tr');

    rows.forEach(function (row) {

        row.style.display =
            row.textContent.toLowerCase().includes(search) ? '' : 'none';

    });

});

</script>

<script src="app.js"></script>

</body>
</html>
