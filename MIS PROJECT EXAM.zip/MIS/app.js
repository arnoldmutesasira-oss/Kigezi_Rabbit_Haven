function go(page){ window.location.href = page; }
function getUser(){ return localStorage.getItem('krh_user') || 'Owner / Manager'; }
function logout(){ localStorage.removeItem('krh_user'); window.location.href='index.php'; }
function audit(action){
  let logs = JSON.parse(localStorage.getItem('krh_audit')||'[]');
  logs.push({user:getUser(), action:action, time:new Date().toLocaleString()});
  localStorage.setItem('krh_audit', JSON.stringify(logs));
}
function searchTable(input, tableId){
  let f=input.value.toUpperCase();
  document.querySelectorAll('#'+tableId+' tbody tr').forEach(r=>{
    r.style.display = r.innerText.toUpperCase().includes(f) ? '' : 'none';
  });
}
document.addEventListener('DOMContentLoaded', ()=>{
  let el=document.getElementById('userLabel');
  if(el) el.innerText = getUser();
});