
<?php
include 'db.php';

$message = "";
$messageType = "success";

// Helper for safe output
function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

// Redirect after successful changes
function redirectPage($msg) {
    header("Location: payments.php?msg=" . urlencode($msg));
    exit;
}

// Display messages
if (isset($_GET['msg'])) {
    $message = $_GET['msg'];
}

// RECORD NEW PAYMENT
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pay'])) {

    $oid = filter_var($_POST['oid'], FILTER_VALIDATE_INT);
    $amt = filter_var($_POST['amt'], FILTER_VALIDATE_FLOAT);
    $method = $_POST['method'] ?? '';

    $methods = ['MTN MoMo', 'Airtel Money', 'Cash', 'Bank'];

    if (!$oid || !$amt || $amt <= 0 || !in_array($method, $methods, true)) {

        $message = "Please enter valid payment details.";
        $messageType = "danger";

    } else {

        $stmt = $conn->prepare(
            "SELECT Total FROM `ORDER` WHERE OrderID = ?"
        );

        $stmt->bind_param("i", $oid);
        $stmt->execute();
        $order = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$order) {

            $message = "Order not found.";
            $messageType = "danger";

        } else {

            $stmt = $conn->prepare(
                "SELECT COALESCE(SUM(Amount),0) AS Paid
                 FROM PAYMENT WHERE OrderID = ?"
            );

            $stmt->bind_param("i", $oid);
            $stmt->execute();
            $payment = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            $balance = (float)$order['Total'] - (float)$payment['Paid'];

            if ($balance <= 0) {

                $message = "This order is already fully paid.";
                $messageType = "warning";

            } elseif ($amt > $balance) {

                $message = "Payment exceeds the remaining balance of UGX " .
                           number_format($balance, 2);
                $messageType = "danger";

            } else {

                $stmt = $conn->prepare(
                    "INSERT INTO PAYMENT
                    (OrderID, Amount, Method, PaymentDate)
                    VALUES (?, ?, ?, CURDATE())"
                );

                $stmt->bind_param("ids", $oid, $amt, $method);

                if ($stmt->execute()) {
                    $stmt->close();
                    redirectPage("Payment successfully recorded.");
                } else {
                    $message = "Payment could not be saved.";
                    $messageType = "danger";
                    $stmt->close();
                }
            }
        }
    }
}


// UPDATE ORDER AND CUSTOMER DETAILS
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_order'])) {

    $oid = filter_var($_POST['edit_oid'], FILTER_VALIDATE_INT);
    $customerName = trim($_POST['customer_name'] ?? '');
    $total = filter_var($_POST['total'], FILTER_VALIDATE_FLOAT);
    $orderDate = $_POST['order_date'] ?? '';

    if (!$oid || $customerName === '' || $total === false ||
        $total < 0 || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $orderDate)) {

        $message = "Please enter valid order information.";
        $messageType = "danger";

    } else {

        $stmt = $conn->prepare(
            "SELECT o.CustomerID,
                    COALESCE(p.Paid,0) AS Paid
             FROM `ORDER` o
             LEFT JOIN (
                 SELECT OrderID, SUM(Amount) AS Paid
                 FROM PAYMENT
                 GROUP BY OrderID
             ) p ON o.OrderID = p.OrderID
             WHERE o.OrderID = ?"
        );

        $stmt->bind_param("i", $oid);
        $stmt->execute();
        $existing = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$existing) {

            $message = "Order not found.";
            $messageType = "danger";

        } elseif ($total < (float)$existing['Paid']) {

            $message = "Order total cannot be less than the amount already paid.";
            $messageType = "danger";

        } else {

            $conn->begin_transaction();

            try {

                $stmt = $conn->prepare(
                    "UPDATE `ORDER`
                     SET Total = ?, OrderDate = ?
                     WHERE OrderID = ?"
                );

                $stmt->bind_param("dsi", $total, $orderDate, $oid);
                $stmt->execute();
                $stmt->close();

                $customerID = $existing['CustomerID'];

                if ($customerID !== null) {

                    $stmt = $conn->prepare(
                        "UPDATE CUSTOMER
                         SET CustomerName = ?
                         WHERE CustomerID = ?"
                    );

                    $stmt->bind_param("si", $customerName, $customerID);
                    $stmt->execute();
                    $stmt->close();

                }

                $conn->commit();
                redirectPage("Order and customer details updated successfully.");

            } catch (Throwable $ex) {

                $conn->rollback();
                $message = "Unable to update order details.";
                $messageType = "danger";

            }
        }
    }
}


// UPDATE INDIVIDUAL PAYMENT
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_payment'])) {

    $pid = filter_var($_POST['payment_id'], FILTER_VALIDATE_INT);
    $amt = filter_var($_POST['payment_amount'], FILTER_VALIDATE_FLOAT);
    $method = $_POST['payment_method'] ?? '';
    $date = $_POST['payment_date'] ?? '';

    $methods = ['MTN MoMo', 'Airtel Money', 'Cash', 'Bank'];

    if (!$pid || $amt === false || $amt <= 0 ||
        !in_array($method, $methods, true) ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {

        $message = "Please enter valid payment details.";
        $messageType = "danger";

    } else {

        $stmt = $conn->prepare(
            "SELECT p.OrderID,
                    COALESCE(o.Total,0) AS Total
             FROM PAYMENT p
             LEFT JOIN `ORDER` o ON p.OrderID = o.OrderID
             WHERE p.PaymentID = ?"
        );

        $stmt->bind_param("i", $pid);
        $stmt->execute();
        $paymentOrder = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$paymentOrder) {

            $message = "Payment record not found.";
            $messageType = "danger";

        } else {

            // Other payments on this order, excluding the payment being edited
            $stmt = $conn->prepare(
                "SELECT COALESCE(SUM(Amount),0) AS OtherPaid
                 FROM PAYMENT
                 WHERE OrderID = ? AND PaymentID != ?"
            );

            $stmt->bind_param(
                "ii",
                $paymentOrder['OrderID'],
                $pid
            );

            $stmt->execute();
            $other = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            $remaining = (float)$paymentOrder['Total'] -
                         (float)$other['OtherPaid'];

            if ($amt > $remaining) {

                $message = "Payment exceeds the available order balance of UGX " .
                           number_format(max(0, $remaining), 2);
                $messageType = "danger";

            } else {

                $stmt = $conn->prepare(
                    "UPDATE PAYMENT
                     SET Amount = ?, Method = ?, PaymentDate = ?
                     WHERE PaymentID = ?"
                );

                $stmt->bind_param("dssi", $amt, $method, $date, $pid);

                if ($stmt->execute()) {
                    $stmt->close();
                    redirectPage("Payment details updated successfully.");
                } else {
                    $message = "Payment update failed.";
                    $messageType = "danger";
                    $stmt->close();
                }
            }
        }
    }
}


// DELETE PAYMENT
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_payment'])) {

    $pid = filter_var($_POST['delete_payment_id'], FILTER_VALIDATE_INT);

    if ($pid) {

        $stmt = $conn->prepare(
            "DELETE FROM PAYMENT WHERE PaymentID = ?"
        );

        $stmt->bind_param("i", $pid);

        if ($stmt->execute() && $stmt->affected_rows > 0) {
            $stmt->close();
            redirectPage("Payment record deleted successfully.");
        } else {
            $message = "Payment could not be deleted.";
            $messageType = "danger";
            $stmt->close();
        }

    } else {

        $message = "Invalid payment record.";
        $messageType = "danger";

    }
}


// FETCH ORDER FOR EDITING
$editOrder = null;

if (isset($_GET['edit_order'])) {

    $editID = filter_var($_GET['edit_order'], FILTER_VALIDATE_INT);

    if ($editID) {

        $stmt = $conn->prepare(
            "SELECT o.OrderID, o.CustomerID, c.CustomerName,
                    o.Total, o.OrderDate
             FROM `ORDER` o
             LEFT JOIN CUSTOMER c ON o.CustomerID = c.CustomerID
             WHERE o.OrderID = ?"
        );

        $stmt->bind_param("i", $editID);
        $stmt->execute();
        $editOrder = $stmt->get_result()->fetch_assoc();
        $stmt->close();
    }
}


// FETCH PAYMENT FOR EDITING
$editPayment = null;

if (isset($_GET['edit_payment'])) {

    $editPID = filter_var($_GET['edit_payment'], FILTER_VALIDATE_INT);

    if ($editPID) {

        $stmt = $conn->prepare(
            "SELECT PaymentID, OrderID, Amount, Method, PaymentDate
             FROM PAYMENT
             WHERE PaymentID = ?"
        );

        $stmt->bind_param("i", $editPID);
        $stmt->execute();
        $editPayment = $stmt->get_result()->fetch_assoc();
        $stmt->close();
    }
}

?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Payments - Kigezi Rabbit Haven</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link rel="stylesheet" href="style.css">

</head>

<body>

<div class="topbar d-flex justify-content-between">

    <div>
        <h3 class="m-0">
            <img src="logo2.jpeg" width="100" height="100" alt="Logo">
            PAYMENTS
        </h3>
        <small>Cash / Mobile Money / Bank</small>
    </div>

    <div>
        <div id="userLabel"></div>
        <button class="btn btn-light btn-sm" onclick="logout()">
            Logout
        </button>
    </div>

</div>


<div class="container-fluid p-3">

<ul class="nav nav-pills mb-3 flex-wrap">

    <li class="nav-item">
        <button class="nav-link" onclick="go('dashboard.php')">Dashboard</button>
    </li>

    <li class="nav-item">
        <button class="nav-link" onclick="go('rabbits.php')">Rabbits</button>
    </li>

    <li class="nav-item">
        <button class="nav-link" onclick="go('breeding.php')">Breeding</button>
    </li>

    <li class="nav-item">
        <button class="nav-link" onclick="go('feed.php')">Feed & Store</button>
    </li>

    <li class="nav-item">
        <button class="nav-link" onclick="go('health.php')">Health</button>
    </li>

    <li class="nav-item">
        <button class="nav-link" onclick="go('sales.php')">Sales</button>
    </li>

    <li class="nav-item">
        <button class="nav-link active" onclick="go('payments.php')">Payments</button>
    </li>

    <li class="nav-item">
        <button class="nav-link" onclick="go('reports.php')">Reports</button>
    </li>

</ul>


<?php if ($message): ?>

    <div class="alert alert-<?php echo e($messageType); ?> alert-dismissible fade show">
        <?php echo e($message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>

<?php endif; ?>


<!-- EDIT ORDER FORM -->
<?php if ($editOrder): ?>

<div class="card p-3 mb-4">

    <h5>Edit Customer and Order Details</h5>

    <form method="POST" class="row g-3">

        <input type="hidden" name="edit_oid"
               value="<?php echo e($editOrder['OrderID']); ?>">

        <div class="col-md-3">
            <label class="form-label">Order ID</label>
            <input class="form-control"
                   value="<?php echo e($editOrder['OrderID']); ?>"
                   disabled>
        </div>

        <div class="col-md-3">
            <label class="form-label">Customer Name</label>
            <input type="text" name="customer_name"
                   class="form-control"
                   value="<?php echo e($editOrder['CustomerName']); ?>"
                   required>
        </div>

        <div class="col-md-3">
            <label class="form-label">Order Total (UGX)</label>
            <input type="number" name="total"
                   class="form-control"
                   min="0" step="0.01"
                   value="<?php echo e($editOrder['Total']); ?>"
                   required>
        </div>

        <div class="col-md-3">
            <label class="form-label">Order Date</label>
            <input type="date" name="order_date"
                   class="form-control"
                   value="<?php echo e($editOrder['OrderDate']); ?>"
                   required>
        </div>

        <div class="col-12">
            <button type="submit" name="update_order"
                    class="btn btn-green">
                Save Order Changes
            </button>

            <a href="payments.php" class="btn btn-secondary">
                Cancel
            </a>
        </div>

    </form>

</div>

<?php elseif (isset($_GET['edit_order'])): ?>

<div class="alert alert-danger">Order not found.</div>

<?php endif; ?>


<!-- EDIT PAYMENT FORM -->
<?php if ($editPayment): ?>

<div class="card p-3 mb-4">

    <h5>Edit Payment Record #<?php echo e($editPayment['PaymentID']); ?></h5>

    <form method="POST" class="row g-3">

        <input type="hidden" name="payment_id"
               value="<?php echo e($editPayment['PaymentID']); ?>">

        <div class="col-md-3">
            <label class="form-label">Order ID</label>
            <input class="form-control"
                   value="<?php echo e($editPayment['OrderID']); ?>"
                   disabled>
        </div>

        <div class="col-md-3">
            <label class="form-label">Payment Amount (UGX)</label>
            <input type="number" name="payment_amount"
                   class="form-control"
                   min="0.01" step="0.01"
                   value="<?php echo e($editPayment['Amount']); ?>"
                   required>
        </div>

        <div class="col-md-3">
            <label class="form-label">Payment Method</label>

            <select name="payment_method" class="form-select" required>

                <?php
                $methods = ['MTN MoMo', 'Airtel Money', 'Cash', 'Bank'];

                foreach ($methods as $method):
                ?>

                    <option value="<?php echo e($method); ?>"
                        <?php echo $editPayment['Method'] === $method ? 'selected' : ''; ?>>
                        <?php echo e($method); ?>
                    </option>

                <?php endforeach; ?>

            </select>
        </div>

        <div class="col-md-3">
            <label class="form-label">Payment Date</label>
            <input type="date" name="payment_date"
                   class="form-control"
                   value="<?php echo e($editPayment['PaymentDate']); ?>"
                   required>
        </div>

        <div class="col-12">

            <button type="submit" name="update_payment"
                    class="btn btn-green">
                Save Payment Changes
            </button>

            <a href="payments.php" class="btn btn-secondary">
                Cancel
            </a>

        </div>

    </form>

</div>

<?php elseif (isset($_GET['edit_payment'])): ?>

<div class="alert alert-danger">Payment record not found.</div>

<?php endif; ?>


<!-- RECORD PAYMENT -->
<div class="card p-3 mb-4">

    <h5>Record Client Payment</h5>

    <form method="POST" class="row g-2">

        <div class="col-md-3">
            <input name="oid" type="number"
                   class="form-control"
                   placeholder="Order ID e.g. 1"
                   min="1" required>
        </div>

        <div class="col-md-3">
            <input name="amt" type="number"
                   class="form-control"
                   placeholder="Amount UGX"
                   min="0.01" step="0.01" required>
        </div>

        <div class="col-md-3">

            <select name="method" class="form-select">

                <option>MTN MoMo</option>
                <option>Airtel Money</option>
                <option>Cash</option>
                <option>Bank</option>

            </select>

        </div>

        <div class="col-md-3">

            <button class="btn btn-green w-100" name="pay">
                Record Payment & Issue Receipt
            </button>

        </div>

    </form>

</div>


<!-- CUSTOMER BALANCES -->
<div class="card p-3 mb-4">

    <h5>Client Payment Balances</h5>

    <div class="table-responsive">

        <table class="table table-striped table-hover mt-3">

            <thead>
                <tr>
                    <th>Order</th>
                    <th>Customer</th>
                    <th>Total (UGX)</th>
                    <th>Paid (UGX)</th>
                    <th>Balance (UGX)</th>
                    <th>Ageing</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>

            <?php

            $sql = "
                SELECT
                    o.OrderID,
                    c.CustomerName,
                    o.Total,
                    o.OrderDate,
                    COALESCE(p.Paid,0) AS Paid

                FROM `ORDER` o

                LEFT JOIN CUSTOMER c
                    ON o.CustomerID = c.CustomerID

                LEFT JOIN (
                    SELECT OrderID, SUM(Amount) AS Paid
                    FROM PAYMENT
                    GROUP BY OrderID
                ) p ON o.OrderID = p.OrderID

                ORDER BY o.OrderDate DESC
            ";

            $r = $conn->query($sql);

            if ($r && $r->num_rows > 0):

                while ($x = $r->fetch_assoc()):

                    $total = (float)$x['Total'];
                    $paid = (float)$x['Paid'];
                    $bal = max(0, $total - $paid);

                    $age = max(0, (int)floor(
                        (time() - strtotime($x['OrderDate'])) / 86400
                    ));

                    if ($bal <= 0) {
                        $status = "PAID";
                        $badge = "success";
                    } elseif ($paid > 0) {
                        $status = "PARTIALLY PAID";
                        $badge = "warning";
                    } else {
                        $status = "UNPAID";
                        $badge = "danger";
                    }

            ?>

                <tr>

                    <td><?php echo e($x['OrderID']); ?></td>

                    <td><?php echo e($x['CustomerName'] ?? 'Unknown'); ?></td>

                    <td><?php echo number_format($total, 2); ?></td>

                    <td class="text-success">
                        <?php echo number_format($paid, 2); ?>
                    </td>

                    <td class="<?php echo $bal > 0 ? 'text-danger' : 'text-success'; ?>">
                        <?php echo number_format($bal, 2); ?>
                    </td>

                    <td>
                        <?php echo $age; ?> days

                        <?php if ($bal > 0 && $age > 30): ?>
                            <span class="text-danger fw-bold">OVERDUE</span>
                        <?php endif; ?>
                    </td>

                    <td>
                        <span class="badge bg-<?php echo $badge; ?>">
                            <?php echo $status; ?>
                        </span>
                    </td>

                    <td>
                        <a href="payments.php?edit_order=<?php echo e($x['OrderID']); ?>"
                           class="btn btn-primary btn-sm">
                            Edit Order
                        </a>
                    </td>

                </tr>

            <?php

                endwhile;

            else:

            ?>

                <tr>
                    <td colspan="8" class="text-center">
                        No client orders found.
                    </td>
                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>


<!-- PAYMENT HISTORY -->
<div class="card p-3">

    <h5>Payment History & Editing</h5>

    <div class="table-responsive">

        <table class="table table-striped table-hover mt-3">

            <thead>
                <tr>
                    <th>Payment ID</th>
                    <th>Order ID</th>
                    <th>Amount (UGX)</th>
                    <th>Method</th>
                    <th>Payment Date</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>

            <?php

            $history = $conn->query(
                "SELECT PaymentID, OrderID, Amount, Method, PaymentDate
                 FROM PAYMENT
                 ORDER BY PaymentDate DESC, PaymentID DESC"
            );

            if ($history && $history->num_rows > 0):

                while ($p = $history->fetch_assoc()):

            ?>

                <tr>

                    <td><?php echo e($p['PaymentID']); ?></td>

                    <td><?php echo e($p['OrderID']); ?></td>

                    <td><?php echo number_format((float)$p['Amount'], 2); ?></td>

                    <td><?php echo e($p['Method']); ?></td>

                    <td><?php echo e($p['PaymentDate']); ?></td>

                    <td>

                        <a href="payments.php?edit_payment=<?php echo e($p['PaymentID']); ?>"
                           class="btn btn-primary btn-sm">
                            Edit
                        </a>

                        <form method="POST" class="d-inline"
                              onsubmit="return confirm('Are you sure you want to delete this payment? The order balance will be recalculated.');">

                            <input type="hidden" name="delete_payment_id"
                                   value="<?php echo e($p['PaymentID']); ?>">

                            <button type="submit" name="delete_payment"
                                    class="btn btn-danger btn-sm">
                                Delete
                            </button>

                        </form>

                    </td>

                </tr>

            <?php

                endwhile;

            else:

            ?>

                <tr>
                    <td colspan="6" class="text-center">
                        No payment records found.
                    </td>
                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="app.js"></script>

</body>
</html>
