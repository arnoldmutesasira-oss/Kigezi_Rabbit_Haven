<?php include 'db.php'; ?>
<!DOCTYPE html><html><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Reports - Kigezi Rabbit Haven</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css">
</head><body>
<div class="topbar d-flex justify-content-between"><div><h3 class="m-0"> <img src="logo2.jpeg" width=100px height=100;> REPORTS</h3><small>1 Click, Not 3 Days</small></div><div><div id="userLabel"></div><button class="btn btn-light btn-sm" onclick="logout()">Logout</button></div></div>
<div class="container-fluid p-3">
<ul class="nav nav-pills mb-3 flex-wrap">
  <li class="nav-item"><button class="nav-link" onclick="go('dashboard.php')">Dashboard</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('rabbits.php')">Rabbits</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('breeding.php')">Breeding</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('feed.php')">Feed & Store</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('health.php')">Health</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('sales.php')">Sales</button></li>
  <li class="nav-item"><button class="nav-link" onclick="go('payments.php')">Payments</button></li>
  <li class="nav-item"><button class="nav-link active" onclick="go('reports.php')">Reports</button></li>
</ul>
<div class="card p-3 bg-dark text-white">
  <h5> REPORTS</h5>
  <p>Operational: Daily Task List • Tactical: Kindling Rate • Mortality • Feed Conversion • Sales by Customer<br>Strategic: Profit by Product • Cash Flow • Herd Growth</p>
  <?php
    $herd=$conn->query("SELECT COUNT(*) c FROM RABBIT")->fetch_assoc()['c'];
    $sales=$conn->query("SELECT IFNULL(SUM(Total),0) s FROM `ORDER`")->fetch_assoc()['s'];
    $mort=$conn->query("SELECT IFNULL(AVG(Mortality),0) m FROM BREEDING_EVENT")->fetch_assoc()['m'];
    echo "<p>Herd: <b>$herd</b> • Total Sales: <b>UGX ".number_format($sales)."</b> • Avg Mortality: <b>".round($mort,1)."%</b></p>";
  ?>
  <button class="btn btn-light m-1" onclick="window.print()">Export PDF / Print</button>
  <button class="btn btn-success m-1" onclick="alert('Excel export - use phpMyAdmin Export')">Export Excel</button>
  <button class="btn btn-warning m-1" onclick="showAudit()">Show Audit Trail</button>
  <div id="reportResult" class="mt-2"></div>
  <small class="text-white-50">Audit Trail: Who changed what, when. Daily backup ON. Monthly Report in &lt;1 hour (was 3 days on paper).</small>
</div></div>
<script src="app.js"></script>
<script>
function showAudit(){
  let logs=JSON.parse(localStorage.getItem('krh_audit')||'[]');
  document.getElementById('reportResult').innerHTML='<div class="alert alert-light text-dark">'+(logs.length?logs.map(l=>l.time+' - '+l.user+' - '+l.action).join('<br>'):'No actions yet')+'</div>';
}
</script></body></html>